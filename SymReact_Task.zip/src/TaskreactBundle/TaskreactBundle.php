<?php

namespace TaskreactBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TaskreactBundle extends Bundle
{
}
